const express = require("express");
const multer = require("multer");

const router = express.Router();
const upload = multer({ storage: multer.memoryStorage() });

// Temporary fake responses for testing
const fakeCropAnalysis = {
  "tomato": "Tomato Problem Analysis:\n\nPossible Causes:\n1. Early Blight - fungal disease from soil\n2. Nutrient deficiency - lack of nitrogen\n3. Overwatering - causes root rot\n\nSolutions:\n1. Apply fungicide spray every 7-10 days\n2. Add balanced fertilizer\n3. Water only at soil level, not leaves\n\nPrevention Tips:\n1. Use mulch to prevent soil splash\n2. Remove lower leaves regularly\n3. Ensure good air circulation",
  
  "rice": "Rice Problem Analysis:\n\nPossible Causes:\n1. Blast disease - fungal infection\n2. Brown spot - pathogenic fungus\n3. Stem rot - bacterial disease\n\nSolutions:\n1. Apply copper fungicide\n2. Drain excess water\n3. Use disease-resistant varieties\n\nPrevention Tips:\n1. Maintain proper water level\n2. Use quality seeds\n3. Practice crop rotation",
  
  "wheat": "Wheat Problem Analysis:\n\nPossible Causes:\n1. Rust disease - fungal infection\n2. Powdery mildew - fungal disease\n3. Septoria - leaf spot disease\n\nSolutions:\n1. Apply sulfur dust or fungicide\n2. Improve air circulation\n3. Remove infected plants\n\nPrevention Tips:\n1. Use resistant varieties\n2. Avoid overcrowding\n3. Clean farming tools regularly"
};

router.post("/", upload.single("image"), async (req, res) => {
  try {
    const { cropName, description, language } = req.body;

    if (!cropName || !description) {
      return res.status(400).json({
        success: false,
        error: "cropName and description are required"
      });
    }

    // Temporary: Return fake response based on crop name
    const lowerCropName = cropName.toLowerCase();
    let aiResponse = fakeCropAnalysis[lowerCropName] || 
      `${cropName} Problem Analysis:\n\nNote: This is a temporary response. Real AI analysis will be added later.\n\nBased on your description: "${description}"\n\nGeneral Solutions:\n1. Consult local agricultural extension office\n2. Take crop samples to lab for diagnosis\n3. Use recommended pesticides for your region`;

    res.json({
      success: true,
      cropName: cropName,
      problem: description,
      result: aiResponse,
      status: "temporary_response"
    });

  } catch (err) {
    console.error("❌ Error:", err.message);
    res.status(500).json({
      success: false,
      error: err.message || "Server error"
    });
  }
});

module.exports = router;