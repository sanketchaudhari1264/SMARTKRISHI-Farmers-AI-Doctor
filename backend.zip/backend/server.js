const express = require("express");
const cors = require("cors");
// Remove this line: require("dotenv").config();

const analyzeRoute = require("./routes/analyze");

const app = express();

app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

app.use("/api/analyze", analyzeRoute);

// Health check endpoint
app.get("/", (req, res) => {
  res.json({ message: "SmartKrishi Backend Running" });
});

app.listen(5000, () => {
  console.log("✅ Server running on port 5000");
});